// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

// Custom exception
class CustomException : public std::exception {
private:
    const char* message;

public:
    CustomException(const char* msg) : message(msg) {}
    const char* what() const noexcept override {
        return message;
    }
};

bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception
    throw std::runtime_error("Throwing a standard exception.");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catching the standard exception
    catch (std::exception& e) {
		std::cout << "Caught an exception: " << e.what() << std::endl;
	}
    // Throwing a custom exception
    throw CustomException("Custom exception from std::exception");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den){


    if (den == 0)
	{
        // Throwing a divide by zero exception
		throw std::runtime_error("Divide by zero error");
	}
    return (num / den);
}

void do_division() noexcept
{


    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Catching the divide by zero exception
    catch (std::runtime_error& e) {
        std::cout << "Divide exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try{
        do_division();
        do_custom_application_logic();
    }
    // custom exception
    catch (CustomException& e) {
		std::cout << "Custom exception: " << e.what() << std::endl;
	}
    // standard exception
	catch (std::exception& e) {
		std::cout << "Standard exception: " << e.what() << std::endl;
	}
	// uncaught exception
	catch (...) {
		std::cout << "Uncaught exception." << std::endl;
	}

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu